package itesm.mx.mindset;

/**
 * Created by Jibril on 11/9/17.
 */

public interface OnItemClickedListener {
    public void onEventSelected(int position);
}
